package MyServlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.Document;
import java.io.*;
import java.sql.*;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
    Statement stmt;

    public void DBConnection() throws SQLException, ClassNotFoundException {
        String url = "jdbc:sqlite:C:\\Users\\dead_\\eclipse-workspace\\RegistrationPR2\\src\\main\\webapp\\users.db";
        String user = "root";
        String password = "";

        try {
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public Statement getStatement() {
        try {
            stmt = con.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stmt;
    }
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset=\"utf-8\"/>");
        out.println("</head>");
        out.println("<body>");
        try {
            DBConnection();
            getStatement();
            String Login, Password, Name, EMail, Gender, BDay, MarStatus, AboutYourself, Mailing, Agreement;
            Login = request.getParameter("login");
            Password = request.getParameter("password");
            Name = request.getParameter("name");
            EMail = request.getParameter("email");
            Gender = request.getParameter("gender");
            BDay = request.getParameter("birthday");
            MarStatus = request.getParameter("marstatus");
            AboutYourself = request.getParameter("aboutyourself");
            Mailing = request.getParameter("mailing");
            Agreement = request.getParameter("agreement");;
            if(Login.length() > 3 || Password.length() > 3 || Name.length() > 3 || EMail.length() > 3)
            {
                stmt.executeUpdate("INSERT INTO users (login, password, fullname, email, gender, birthday, marstatus, mailing, agreement, aboutyourself) values ('" + Login + "', '" + Password + "', '" + Name + "', '" + EMail + "', '" + Gender + "', '" + BDay + "', '" + MarStatus + "', '" + Mailing + "', '" + Agreement + "', '" + AboutYourself + "')");
                out.println("<p>Database has been successfully updated</p>");
            }
            stmt.close();
            getStatement();
            ResultSet res = stmt.executeQuery("SELECT * FROM users");
            while (res.next()) {
                out.println("<div>" + res.getString("id") + " - " + res.getString("fullname") + " " + res.getString("email")+ "</div>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            out.println("<p>There was an error writing data to the database, double-check the entered data and try again</p>");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        out.println("</body>");
        out.println("</html>");
        out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
